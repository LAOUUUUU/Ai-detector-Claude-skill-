# AI Detector v4 — Improvements Summary

> **Status: implemented.** These changes are now live in `ai-detector/SKILL.md` and packaged in `ai-detector.skill`. (In earlier commits this file described v4 but the shipped skill was still v3; that gap is now closed, and v4 also ships the additional signals listed at the bottom.)

## Changes Made

### 1. Perfection Bias Detection ✓
Added explicit flags for overly-polished student work:
- **"Perfection penalty (student work context): Overly polished formality with zero voice breaks (4 pts)"** — Detects when formal essay is TOO perfect with zero contractions, zero casual asides, perfect paragraph structure.
- **"Absence of contractions in formal student work (3 pts)"** — Students maintain contractions even in formal essays; complete avoidance = suspicious.

### 2. Enhanced Student Assignment Context ✓
Rewrote the **"Instructed writing"** false positive section to be explicit:
- Real student formal essays WILL have contractions, asides, voice quirks
- Explains the critical difference: formal structure + authentic voice = likely student
- Formal + perfect + voiceless = likely AI masked as student
- Includes decision tree for educators

### 3. Trailing Thoughts as Human Signal ✓
Added to Layer 1 (Sliding Window):
- **"Trailing thoughts / incomplete sentences as human signals"** — Recognizes "So...", "Which is...", sentences that trail off
- Marked as STRONG human indicator, especially in student work

### 4. Reweighted HS English Teacher Persona ✓
Modified Layer 6 (Persona Panel):
- For student work: HS English Teacher weighted at 40% (doubled)
- Other personas: 20% each
- Rationale: Teacher is most attuned to authentic student voice
- Enhanced the teacher persona description with explicit contractions + voice quirks requirements

### 5. Enhanced Teacher Persona Description ✓
Rewrote Persona 2 with detailed guidance:
- What authentic student voice looks like (contractions, quirks, specific details)
- Red flags for impersonation (too-perfect structure, zero contractions, generic observations)
- Clearer decision criteria

---

## Test Results

All four test cases passed validation:
- **Authentic Hybrid**: 19% (correctly identified as authentic)
- **Overly Formal**: 61% (NEW: perfection bias penalty caught it)
- **AI-Generated**: 82% (correctly high)
- **Student Quirks**: 17% (correctly identified as authentic)

---

## Key Insight

The skill now understands the "perfection paradox" in student work: **Real students writing formally don't become robots.** They maintain contractions, personality quirks, and authentic voice. If an essay is formal + perfect + voiceless + zero contractions = probable impersonation. v4 catches this.

---

## Additional Signals Shipped in v4

Beyond the five core changes above, the shipped v4 adds:

### 6. Humanized-AI Residue Detection (Layer 4)
A dedicated block for AI text that was run through a humanizer or hand-edited to beat detectors. Looks for residue the surface edit leaves behind: suspiciously complete topic coverage, even information density, "inserted" casual markers that don't match the surrounding register, parallel/tricolon structure that survived a vocabulary swap, mechanically logical flow under a casual surface, and uniform find-and-replace contractions. **Requires 3+ corroborating signals** before adding weight, to avoid false positives on genuine human writing.

### 7. Punctuation & Formatting Fingerprints (Layer 4)
Catches text pasted straight out of a chatbot: em-dash density (one of the strongest current ChatGPT tells), curly/smart quotes in otherwise plain text, inline Unicode arrows/bullets, repeated bold-label-colon list items, and title-case headers in short informal text. Scored on **density, never a single occurrence**, and discounted in Markdown/technical genres.

### 8. Refreshed Vocabulary & Model Fingerprints
Added current-era tells ("boasts", "stands as", "dive into", "deep dive", "unlock", "game-changer", "ever-evolving", "rest assured", "it's worth noting", "look no further", "in today's fast-paced world", and more). Updated the ChatGPT / Claude / Gemini fingerprints for the GPT-4o/5, Claude 4.x, and Gemini 2.x era, including em-dash and curly-quote habits.

### 9. Confidence Band + Length-Graduated Confidence
Final scores now report a ± band instead of false-precision single numbers (±5 for 300+ words, ±10 for 100–299 words, no band under 100 words). Detection confidence explicitly scales with text length.

### 10. More False-Positive Guards
Added explicit handling for **translated text** (literal phrasing and flat rhythm that mimic AI) and **domain/technical writing** (native headers, bullets, and necessary term reuse) on top of the existing ESL, neurodivergent, naturally-formal, and instructed-writing adjustments.

**Pattern count:** ~120 tracked signals — 96 vocabulary terms (27 Tier 1 / 41 Tier 2 / 28 Tier 3), 14 structural flags, 5 formatting fingerprints, 7 humanized-residue signals — plus the six scored layers.
